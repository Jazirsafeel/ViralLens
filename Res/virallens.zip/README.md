# ViralLens

AI Content Virality Analyzer — built with Next.js, Supabase, and Grok API.

## Setup

### 1. Install deps
```bash
npm install
```

### 2. Supabase
1. Create project at https://supabase.com
2. Go to SQL Editor → paste contents of `supabase-schema.sql` → run
3. Copy your project URL and anon key from Settings → API

### 3. Grok API key
Get yours at https://console.x.ai

### 4. Env vars
```bash
cp .env.local.example .env.local
```
Fill in:
```
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
GROK_API_KEY=xai-...
```

### 5. Run
```bash
npm run dev
```
Open http://localhost:3000

## Flow
1. Sign up / log in
2. Paste content in the text area
3. Click "Analyze content"
4. Get viral score, metric breakdown, suggestions, and rewritten hook
5. Results auto-saved to Supabase — revisit from dashboard

## Stack
- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- Supabase (auth + database)
- Grok API (`grok-3` model via `https://api.x.ai/v1`)
