'use client'

export default function AnalysisSkeleton() {
  return (
    <div className="space-y-6 animate-fade-in">
      {/* Score + summary skeleton */}
      <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6 flex flex-col sm:flex-row gap-6 items-center sm:items-start">
        <div className="flex flex-col items-center gap-2 flex-shrink-0">
          <div className="w-36 h-36 rounded-full bg-gray-800 animate-pulse" />
          <div className="h-4 w-28 bg-gray-800 rounded animate-pulse" />
        </div>
        <div className="flex-1 w-full space-y-3">
          <div className="h-5 w-24 bg-gray-800 rounded animate-pulse" />
          <div className="h-4 w-full bg-gray-800 rounded animate-pulse" />
          <div className="h-4 w-5/6 bg-gray-800 rounded animate-pulse" />
          <div className="h-4 w-4/6 bg-gray-800 rounded animate-pulse" />
        </div>
      </div>

      {/* Metrics skeleton */}
      <div>
        <div className="h-5 w-36 bg-gray-800 rounded animate-pulse mb-3" />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {[0, 1, 2, 3].map(i => (
            <div key={i} className="bg-gray-800 rounded-xl border border-gray-700 p-4 space-y-3">
              <div className="flex justify-between">
                <div className="h-4 w-28 bg-gray-700 rounded animate-pulse" />
                <div className="h-4 w-10 bg-gray-700 rounded animate-pulse" />
              </div>
              <div className="h-1.5 w-full bg-gray-700 rounded-full animate-pulse" />
              <div className="h-3 w-40 bg-gray-700 rounded animate-pulse" />
            </div>
          ))}
        </div>
      </div>

      {/* Hook skeleton */}
      <div className="bg-gray-900 rounded-2xl border border-indigo-500/20 p-6 space-y-3">
        <div className="h-5 w-32 bg-gray-800 rounded animate-pulse" />
        <div className="space-y-2">
          <div className="h-3 w-16 bg-gray-800 rounded animate-pulse" />
          <div className="h-4 w-full bg-gray-800 rounded animate-pulse" />
        </div>
        <div className="space-y-2">
          <div className="h-3 w-16 bg-gray-800 rounded animate-pulse" />
          <div className="h-4 w-5/6 bg-indigo-900/40 rounded animate-pulse" />
        </div>
      </div>

      {/* Suggestions skeleton */}
      <div>
        <div className="h-5 w-44 bg-gray-800 rounded animate-pulse mb-3" />
        <div className="space-y-3">
          {[0, 1, 2].map(i => (
            <div key={i} className="flex gap-3 items-start p-3 bg-gray-800 rounded-xl border border-gray-700">
              <div className="w-6 h-6 rounded-full bg-gray-700 animate-pulse flex-shrink-0" />
              <div className="flex-1 space-y-2">
                <div className="h-4 w-full bg-gray-700 rounded animate-pulse" />
                <div className="h-4 w-4/5 bg-gray-700 rounded animate-pulse" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
