'use client'

interface SuggestionListProps {
  suggestions: string[]
  onCopy?: (text: string, label: string) => void
}

export default function SuggestionList({ suggestions, onCopy }: SuggestionListProps) {
  return (
    <div className="space-y-3">
      {suggestions.map((s, i) => (
        <div key={i} className="flex gap-3 items-start p-3 bg-gray-800 rounded-xl border border-gray-700 group">
          <span className="flex-shrink-0 w-6 h-6 rounded-full bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 text-xs font-bold flex items-center justify-center mt-0.5">
            {i + 1}
          </span>
          <p className="text-sm text-gray-300 leading-relaxed flex-1">{s}</p>
          {onCopy && (
            <button
              onClick={() => onCopy(s, `Suggestion ${i + 1}`)}
              className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity text-gray-500 hover:text-indigo-400 mt-0.5"
              title="Copy suggestion"
            >
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
            </button>
          )}
        </div>
      ))}
    </div>
  )
}
