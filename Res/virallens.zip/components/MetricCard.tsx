'use client'

interface MetricCardProps {
  label: string
  value: number
  max?: number
  description?: string
}

export default function MetricCard({ label, value, max = 10, description }: MetricCardProps) {
  const pct = (value / max) * 100
  const barColor =
    pct >= 75 ? 'bg-green-500' :
    pct >= 50 ? 'bg-yellow-500' :
    'bg-red-500'

  return (
    <div className="bg-gray-800 rounded-xl border border-gray-700 p-4">
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm font-medium text-gray-300">{label}</span>
        <span className="text-sm font-bold text-white">{value}<span className="text-gray-500 font-normal">/{max}</span></span>
      </div>
      <div className="w-full bg-gray-700 rounded-full h-1.5">
        <div
          className={`h-1.5 rounded-full transition-all duration-500 ${barColor}`}
          style={{ width: `${pct}%` }}
        />
      </div>
      {description && <p className="text-xs text-gray-500 mt-2">{description}</p>}
    </div>
  )
}
