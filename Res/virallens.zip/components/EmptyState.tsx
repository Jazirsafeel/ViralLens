'use client'

export default function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center animate-fade-in">
      {/* SVG illustration */}
      <svg width="120" height="120" viewBox="0 0 120 120" fill="none" className="mb-6 opacity-80">
        <circle cx="60" cy="60" r="56" fill="#1f2937" stroke="#374151" strokeWidth="2" />
        {/* Graph bars */}
        <rect x="28" y="72" width="12" height="20" rx="3" fill="#4f46e5" opacity="0.4" />
        <rect x="46" y="58" width="12" height="34" rx="3" fill="#4f46e5" opacity="0.6" />
        <rect x="64" y="44" width="12" height="48" rx="3" fill="#4f46e5" opacity="0.9" />
        <rect x="82" y="52" width="12" height="40" rx="3" fill="#4f46e5" opacity="0.7" />
        {/* Sparkle */}
        <circle cx="85" cy="32" r="6" fill="#6366f1" opacity="0.8" />
        <line x1="85" y1="24" x2="85" y2="20" stroke="#818cf8" strokeWidth="1.5" strokeLinecap="round" />
        <line x1="85" y1="40" x2="85" y2="44" stroke="#818cf8" strokeWidth="1.5" strokeLinecap="round" />
        <line x1="77" y1="32" x2="73" y2="32" stroke="#818cf8" strokeWidth="1.5" strokeLinecap="round" />
        <line x1="93" y1="32" x2="97" y2="32" stroke="#818cf8" strokeWidth="1.5" strokeLinecap="round" />
        <line x1="79.5" y1="26.5" x2="76.7" y2="23.7" stroke="#818cf8" strokeWidth="1.5" strokeLinecap="round" />
        <line x1="90.5" y1="37.5" x2="93.3" y2="40.3" stroke="#818cf8" strokeWidth="1.5" strokeLinecap="round" />
      </svg>

      <h3 className="text-lg font-semibold text-white mb-2">No analyses yet</h3>
      <p className="text-sm text-gray-500 max-w-xs leading-relaxed">
        Paste your content above and hit <span className="text-indigo-400 font-medium">Analyze</span> to get your first virality score.
      </p>
    </div>
  )
}
