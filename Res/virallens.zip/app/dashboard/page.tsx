import { redirect } from 'next/navigation'
import { createServerSupabaseClient } from '@/lib/supabase-server'
import Navbar from '@/components/Navbar'
import AnalyzeForm from './AnalyzeForm'

export default async function DashboardPage() {
  const supabase = createServerSupabaseClient()
  const { data: { session } } = await supabase.auth.getSession()

  if (!session) redirect('/login')

  // fetch recent analyses
  const { data: analyses } = await supabase
    .from('analyses')
    .select('id, content, result, created_at')
    .eq('user_id', session.user.id)
    .order('created_at', { ascending: false })
    .limit(5)

  return (
    <div className="min-h-screen bg-gray-950">
      <Navbar />
      <main className="max-w-5xl mx-auto px-4 py-10">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-white">Content Analyzer</h1>
          <p className="text-gray-400 mt-1">Paste your content and get an instant virality analysis</p>
        </div>
        <AnalyzeForm recentAnalyses={analyses ?? []} />
      </main>
    </div>
  )
}
