'use client'

import { useState, useCallback } from 'react'
import { AnalysisResult, Analysis, Platform, PLATFORM_LABELS, MetaSuggestions } from '@/types'
import ScoreGauge from '@/components/ScoreGauge'
import MetricCard from '@/components/MetricCard'
import SuggestionList from '@/components/SuggestionList'
import AnalysisSkeleton from '@/components/AnalysisSkeleton'
import EmptyState from '@/components/EmptyState'
import { ToastContainer, useToast } from '@/components/Toast'
import { CompareResult } from '@/app/api/compare/route'

interface Props {
  recentAnalyses: Analysis[]
}

interface Caption {
  style: string
  text: string
}

interface ToolkitResult {
  hashtags: string[]
  audioSuggestions: { style: string; description: string }[]
}

interface ImageAnalysisResult {
  thumbnailScore: number
  hookStrength: number
  emotionalEngagement: number
  clarity: number
  retentionPotential: number
  summary: string
  suggestions: string[]
  colorFeedback: string
  textOverlayFeedback: string
  faceFeedback: string
  metaSuggestions?: MetaSuggestions
}

type InputMode = 'text' | 'image' | 'video'

// ── Metadata fields per mode ──
interface TextMeta {
  title: string
  description: string
  hashtags: string
}
interface ImageMeta {
  description: string
  altText: string
  hashtags: string
}
interface VideoMeta {
  title: string
  caption: string
  description: string
  thumbnailText: string
  hashtags: string
}

// Platform-aware field config
const PLATFORM_META_CONFIG: Record<string, {
  showTitle: boolean
  captionLabel: string
  showAltText: boolean
  showThumbnailText: boolean
  hashtagLimit: number
  hashtagTip: string
}> = {
  '': { showTitle: true, captionLabel: 'Description', showAltText: false, showThumbnailText: false, hashtagLimit: 10, hashtagTip: 'General hashtags' },
  tiktok: { showTitle: false, captionLabel: 'Caption', showAltText: false, showThumbnailText: false, hashtagLimit: 5, hashtagTip: 'TikTok: 3–5 hashtags work best. Mix niche + trending.' },
  instagram: { showTitle: false, captionLabel: 'Caption', showAltText: true, showThumbnailText: false, hashtagLimit: 30, hashtagTip: 'Instagram: up to 30 hashtags. Mix sizes (big/medium/niche).' },
  youtube: { showTitle: true, captionLabel: 'Description', showAltText: false, showThumbnailText: true, hashtagLimit: 15, hashtagTip: 'YouTube: 3 hashtags shown above title. Add more in description for search.' },
}

interface VideoAnalysisResult {
  viralScore: number
  hookStrength: number
  emotionalEngagement: number
  clarity: number
  retentionPotential: number
  summary: string
  suggestions: string[]
  rewrittenHook: string
  hookScore: number
  hookDiagnosis: string
  hookType: string
  thumbnailScore: number
  colorFeedback: string
  textOverlayFeedback: string
  faceFeedback: string
  thumbnailSuggestions: string[]
  transcript: string
  hasTranscript: boolean
  metaSuggestions?: MetaSuggestions
}

const METRICS = [
  { key: 'hookStrength', label: 'Hook Strength', description: 'How compelling is the opening?' },
  { key: 'emotionalEngagement', label: 'Emotional Engagement', description: 'Does it trigger an emotional response?' },
  { key: 'clarity', label: 'Clarity', description: 'Is the message clear and concise?' },
  { key: 'retentionPotential', label: 'Retention Potential', description: 'Will viewers/readers stick around?' },
] as const

const PLATFORM_ICONS: Record<Platform, string> = {
  tiktok: '🎵',
  instagram: '📸',
  youtube: '▶️',
}

const HOOK_TYPE_COLORS: Record<string, string> = {
  'Question Hook':    'bg-blue-500/10 text-blue-400 border-blue-500/20',
  'Shock Hook':       'bg-red-500/10 text-red-400 border-red-500/20',
  'Story Hook':       'bg-purple-500/10 text-purple-400 border-purple-500/20',
  'Data Hook':        'bg-cyan-500/10 text-cyan-400 border-cyan-500/20',
  'Humor Hook':       'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  'Controversy Hook': 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  'Curiosity Hook':   'bg-green-500/10 text-green-400 border-green-500/20',
  'Pain Hook':        'bg-pink-500/10 text-pink-400 border-pink-500/20',
}

function hookScoreColor(score: number) {
  if (score >= 8) return 'text-green-400'
  if (score >= 5) return 'text-yellow-400'
  return 'text-red-400'
}

// ── Reusable metadata field ──
function MetaField({
  label, hint, value, onChange, placeholder, rows = 1, mono = false, optional = true,
  suggestion, onUseSuggestion,
}: {
  label: string; hint?: string; value: string; onChange: (v: string) => void
  placeholder?: string; rows?: number; mono?: boolean; optional?: boolean
  suggestion?: string; onUseSuggestion?: (v: string) => void
}) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-1.5">
        <label className="text-xs font-medium text-gray-300">{label}</label>
        {optional && <span className="text-xs text-gray-600">optional</span>}
        {hint && <span className="text-xs text-gray-500 ml-auto">{hint}</span>}
      </div>
      {rows > 1 ? (
        <textarea
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          rows={rows}
          className="w-full bg-gray-800 border border-gray-700 rounded-xl px-3 py-2.5 text-white placeholder-gray-600 focus:outline-none focus:border-indigo-500 transition-colors resize-none text-sm leading-relaxed"
        />
      ) : (
        <input
          type="text"
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          className={`w-full bg-gray-800 border border-gray-700 rounded-xl px-3 py-2.5 text-white placeholder-gray-600 focus:outline-none focus:border-indigo-500 transition-colors text-sm ${mono ? 'font-mono' : ''}`}
        />
      )}
      {suggestion && (
        <div className="mt-2 bg-indigo-950/60 border border-indigo-500/20 rounded-lg px-3 py-2 flex items-start gap-2">
          <span className="text-indigo-400 text-xs mt-0.5 flex-shrink-0">✨ AI</span>
          <p className={`text-xs text-indigo-200 flex-1 leading-relaxed ${mono ? 'font-mono' : ''}`}>{suggestion}</p>
          {onUseSuggestion && (
            <button
              onClick={() => onUseSuggestion(suggestion)}
              className="flex-shrink-0 text-xs text-indigo-400 hover:text-indigo-200 border border-indigo-500/40 hover:border-indigo-400 rounded px-2 py-0.5 transition-all"
            >
              Use
            </button>
          )}
        </div>
      )}
    </div>
  )
}

export default function AnalyzeForm({ recentAnalyses }: Props) {
  const [content, setContent]               = useState('')
  const [platform, setPlatform]             = useState<Platform | ''>('')
  const [result, setResult]                 = useState<AnalysisResult | null>(null)
  const [originalContent, setOriginalContent] = useState('')
  const [loading, setLoading]               = useState(false)
  const [error, setError]                   = useState('')
  const [captions, setCaptions]             = useState<Caption[]>([])
  const [loadingCaptions, setLoadingCaptions] = useState(false)
  const [toolkit, setToolkit]               = useState<ToolkitResult | null>(null)
  const [loadingToolkit, setLoadingToolkit] = useState(false)
  const [compareOpen, setCompareOpen]       = useState(false)
  const [competitorContent, setCompetitorContent] = useState('')
  const [compareResult, setCompareResult]   = useState<CompareResult | null>(null)
  const [loadingCompare, setLoadingCompare] = useState(false)
  const [inputMode, setInputMode]           = useState<InputMode>('text')
  const [imageFile, setImageFile]           = useState<File | null>(null)
  const [imagePreview, setImagePreview]     = useState<string | null>(null)
  const [imageResult, setImageResult]       = useState<ImageAnalysisResult | null>(null)
  const [loadingImage, setLoadingImage]     = useState(false)
  const [dragOver, setDragOver]             = useState(false)
  const [videoFile, setVideoFile]           = useState<File | null>(null)
  const [videoPreview, setVideoPreview]     = useState<string | null>(null)
  const [videoResult, setVideoResult]       = useState<VideoAnalysisResult | null>(null)
  const [loadingVideo, setLoadingVideo]     = useState(false)
  const [videoDragOver, setVideoDragOver]   = useState(false)
  const [videoProgress, setVideoProgress]   = useState('')
  const { toasts, addToast, removeToast }   = useToast()

  // ── Metadata state ──
  const [textMeta, setTextMeta]   = useState<TextMeta>({ title: '', description: '', hashtags: '' })
  const [imageMeta, setImageMeta] = useState<ImageMeta>({ description: '', altText: '', hashtags: '' })
  const [videoMeta, setVideoMeta] = useState<VideoMeta>({ title: '', caption: '', description: '', thumbnailText: '', hashtags: '' })
  const [metaOpen, setMetaOpen]   = useState(false)

  async function handleAnalyze() {
    if (!content.trim() || content.trim().length < 10) {
      setError('Content must be at least 10 characters.')
      return
    }
    setLoading(true)
    setError('')
    setResult(null)
    setCaptions([])
    setToolkit(null)

    const res = await fetch('/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content,
        platform: platform || undefined,
        meta: {
          title: textMeta.title || undefined,
          description: textMeta.description || undefined,
          hashtags: textMeta.hashtags || undefined,
        },
      }),
    })

    const data = await res.json()
    setLoading(false)

    if (!res.ok) {
      setError(data.error || 'Something went wrong')
      addToast(data.error || 'Analysis failed', 'error')
    } else {
      setResult(data)
      setOriginalContent(content)
      addToast('Analysis saved!', 'success')
      if (data.metaSuggestions) setMetaOpen(true)
      fetchToolkit(content, platform || undefined)
    }
  }

  async function fetchToolkit(text: string, plt?: Platform | '') {
    setLoadingToolkit(true)
    const res = await fetch('/api/toolkit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: text, platform: plt || undefined }),
    })
    const data = await res.json()
    setLoadingToolkit(false)
    if (res.ok) setToolkit(data)
  }

  async function handleGenerateCaptions() {
    setLoadingCaptions(true)
    setCaptions([])
    const res = await fetch('/api/captions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: originalContent }),
    })
    const data = await res.json()
    setLoadingCaptions(false)
    if (res.ok && data.captions) {
      setCaptions(data.captions)
    } else {
      addToast('Failed to generate captions', 'error')
    }
  }

  const copyToClipboard = useCallback((text: string, label: string) => {
    navigator.clipboard.writeText(text).then(() => addToast(`${label} copied!`, 'success'))
  }, [addToast])

  function handleReAnalyze() {
    setResult(null)
    setCaptions([])
    setToolkit(null)
    setCompareOpen(false)
    setCompareResult(null)
    setCompetitorContent('')
    setImageResult(null)
    setImageFile(null)
    setImagePreview(null)
    setVideoResult(null)
    setVideoFile(null)
    setVideoPreview(null)
    setMetaOpen(false)
  }

  function copyAllMeta() {
    let parts: string[] = []
    if (inputMode === 'text') {
      if (textMeta.title) parts.push(`Title: ${textMeta.title}`)
      if (textMeta.description) parts.push(`\n${textMeta.description}`)
      if (textMeta.hashtags) parts.push(`\n${textMeta.hashtags}`)
    } else if (inputMode === 'image') {
      if (imageMeta.description) parts.push(imageMeta.description)
      if (imageMeta.altText) parts.push(`Alt: ${imageMeta.altText}`)
      if (imageMeta.hashtags) parts.push(`\n${imageMeta.hashtags}`)
    } else if (inputMode === 'video') {
      if (videoMeta.title) parts.push(`Title: ${videoMeta.title}`)
      if (videoMeta.caption) parts.push(videoMeta.caption)
      if (videoMeta.description) parts.push(`\n${videoMeta.description}`)
      if (videoMeta.thumbnailText) parts.push(`Thumbnail: ${videoMeta.thumbnailText}`)
      if (videoMeta.hashtags) parts.push(`\n${videoMeta.hashtags}`)
    }
    copyToClipboard(parts.join('\n'), 'All post metadata')
  }

  function parseHashtags(raw: string) {
    // normalize: strip # prefix for counting, re-add for display
    return raw.split(/[\s,]+/).filter(t => t.trim()).map(t => t.startsWith('#') ? t : `#${t}`)
  }

  function handleImageFile(file: File) {
    if (!file.type.startsWith('image/')) {
      addToast('Please upload an image file (JPEG, PNG, WEBP)', 'error')
      return
    }
    if (file.size > 10 * 1024 * 1024) {
      addToast('Image must be under 10MB', 'error')
      return
    }
    setImageFile(file)
    setImageResult(null)
    const reader = new FileReader()
    reader.onload = e => setImagePreview(e.target?.result as string)
    reader.readAsDataURL(file)
  }

  async function handleAnalyzeImage() {
    if (!imageFile) return
    setLoadingImage(true)
    setImageResult(null)
    const reader = new FileReader()
    reader.onload = async (e) => {
      const dataUrl = e.target?.result as string
      const base64 = dataUrl.split(',')[1]
      const res = await fetch('/api/analyze-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64,
          mediaType: imageFile.type,
          platform: platform || undefined,
          meta: {
            caption: imageMeta.description || undefined,
            altText: imageMeta.altText || undefined,
            hashtags: imageMeta.hashtags || undefined,
          },
        }),
      })
      const data = await res.json()
      setLoadingImage(false)
      if (res.ok) {
        setImageResult(data)
        addToast('Image analyzed!', 'success')
        if (data.metaSuggestions) setMetaOpen(true)
      } else {
        addToast(data.error || 'Image analysis failed', 'error')
      }
    }
    reader.readAsDataURL(imageFile)
  }

  function handleVideoFile(file: File) {
    if (!file.type.startsWith('video/')) {
      addToast('Please upload a video file (MP4, MOV, WEBM)', 'error')
      return
    }
    if (file.size > 25 * 1024 * 1024) {
      addToast('Video must be under 25MB (Whisper API limit)', 'error')
      return
    }
    setVideoFile(file)
    setVideoResult(null)
    const url = URL.createObjectURL(file)
    setVideoPreview(url)
  }

  async function handleAnalyzeVideo() {
    if (!videoFile) return
    setLoadingVideo(true)
    setVideoResult(null)
    setVideoProgress('Reading video file...')

    try {
      // Step 1: read video as base64
      const videoBase64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader()
        reader.onload = e => resolve((e.target?.result as string).split(',')[1])
        reader.onerror = reject
        reader.readAsDataURL(videoFile)
      })

      // Step 2: extract first frame via canvas
      setVideoProgress('Extracting first frame...')
      let frameBase64: string | null = null
      try {
        frameBase64 = await new Promise<string>((resolve, reject) => {
          const video = document.createElement('video')
          video.src = videoPreview!
          video.crossOrigin = 'anonymous'
          video.muted = true
          video.currentTime = 0
          video.onloadeddata = () => {
            const canvas = document.createElement('canvas')
            canvas.width = video.videoWidth || 640
            canvas.height = video.videoHeight || 360
            const ctx = canvas.getContext('2d')
            if (!ctx) { reject(new Error('No canvas context')); return }
            ctx.drawImage(video, 0, 0)
            const dataUrl = canvas.toDataURL('image/jpeg', 0.8)
            resolve(dataUrl.split(',')[1])
          }
          video.onerror = reject
          video.load()
        })
      } catch {
        // Frame extraction failed — continue without it
        frameBase64 = null
      }

      // Step 3: send to API
      setVideoProgress('Transcribing audio & analyzing...')
      const res = await fetch('/api/analyze-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          videoBase64,
          mimeType: videoFile.type,
          fileName: videoFile.name,
          frameBase64,
          platform: platform || undefined,
          meta: {
            title: videoMeta.title || undefined,
            caption: videoMeta.caption || undefined,
            description: videoMeta.description || undefined,
            thumbnailText: videoMeta.thumbnailText || undefined,
            hashtags: videoMeta.hashtags || undefined,
          },
        }),
      })

      const data = await res.json()
      setLoadingVideo(false)
      setVideoProgress('')
      if (res.ok) {
        setVideoResult(data)
        addToast('Video analyzed!', 'success')
        if (data.metaSuggestions) setMetaOpen(true)
      } else {
        addToast(data.error || 'Video analysis failed', 'error')
      }
    } catch (err) {
      setLoadingVideo(false)
      setVideoProgress('')
      addToast('Something went wrong — try a smaller video', 'error')
    }
  }

  async function handleCompare() {
    if (!competitorContent.trim() || competitorContent.trim().length < 10) {
      addToast('Competitor content must be at least 10 characters', 'error')
      return
    }
    setLoadingCompare(true)
    setCompareResult(null)
    const res = await fetch('/api/compare', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        yourContent: originalContent,
        theirContent: competitorContent,
        platform: platform || undefined,
      }),
    })
    const data = await res.json()
    setLoadingCompare(false)
    if (res.ok) {
      setCompareResult(data)
    } else {
      addToast(data.error || 'Compare failed', 'error')
    }
  }

  function loadHistoricResult(a: Analysis) {
    setResult(a.result)
    setOriginalContent(a.content)
    setContent(a.content)
    setPlatform((a.platform as Platform) || '')
    setCaptions([])
    setToolkit(null)
  }

  return (
    <>
      <ToastContainer toasts={toasts} onRemove={removeToast} />

      <div className="space-y-8">

        {/* ── INPUT CARD ── */}
        <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6">

          {/* Mode toggle */}
          <div className="flex gap-1 p-1 bg-gray-800 rounded-xl mb-5 w-fit">
            <button
              onClick={() => { setInputMode('text'); setImageResult(null); setImageFile(null); setImagePreview(null); setMetaOpen(false) }}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                inputMode === 'text'
                  ? 'bg-gray-700 text-white shadow'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              ✍️ Text / Caption
            </button>
            <button
              onClick={() => { setInputMode('image'); setResult(null); setCaptions([]); setToolkit(null); setMetaOpen(false) }}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                inputMode === 'image'
                  ? 'bg-gray-700 text-white shadow'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              🖼️ Thumbnail
            </button>
            <button
              onClick={() => { setInputMode('video'); setResult(null); setCaptions([]); setToolkit(null); setImageResult(null); setMetaOpen(false) }}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                inputMode === 'video'
                  ? 'bg-gray-700 text-white shadow'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              🎬 Video
            </button>
          </div>

          {/* Platform selector */}
          <div className="mb-5">
            <label className="block text-sm font-medium text-gray-300 mb-3">Platform</label>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setPlatform('')}
                className={`px-4 py-2 rounded-xl text-sm font-medium border transition-all ${
                  platform === ''
                    ? 'bg-gray-700 border-gray-500 text-white'
                    : 'bg-gray-800/60 border-gray-700 text-gray-400 hover:border-gray-600'
                }`}
              >
                🌐 General
              </button>
              {(Object.keys(PLATFORM_LABELS) as Platform[]).map(p => (
                <button
                  key={p}
                  onClick={() => setPlatform(p)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium border transition-all ${
                    platform === p
                      ? 'bg-indigo-600 border-indigo-500 text-white'
                      : 'bg-gray-800/60 border-gray-700 text-gray-400 hover:border-gray-600'
                  }`}
                >
                  {PLATFORM_ICONS[p]} {PLATFORM_LABELS[p]}
                </button>
              ))}
            </div>
            {platform && (
              <p className="mt-2 text-xs text-indigo-400">
                {platform === 'tiktok'    && '⚡ Weighting hook strength & trend alignment'}
                {platform === 'instagram' && '✨ Weighting visual appeal & caption quality'}
                {platform === 'youtube'   && '🎯 Weighting retention & thumbnail strength'}
              </p>
            )}
          </div>

          {/* TEXT MODE */}
          {inputMode === 'text' && (
            <>
              <label className="block text-sm font-medium text-gray-300 mb-3">Your content</label>
              <textarea
                value={content}
                onChange={e => setContent(e.target.value)}
                placeholder="Paste your caption, script, post, or hook here..."
                rows={6}
                className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition-colors resize-none text-sm leading-relaxed"
              />
              <div className="flex items-center justify-between mt-3">
                <span className="text-xs text-gray-500">{content.length}/5000</span>
                {error && <span className="text-xs text-red-400">{error}</span>}
              </div>
              <div className="flex gap-3 mt-4">
                <button
                  onClick={handleAnalyze}
                  disabled={loading || content.trim().length < 10}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-medium py-3 rounded-xl transition-colors flex items-center justify-center gap-2 text-sm"
                >
                  {loading ? (
                    <>
                      <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/>
                      </svg>
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                      Analyze content
                    </>
                  )}
                </button>
                {result && (
                  <button
                    onClick={handleReAnalyze}
                    className="px-4 py-3 bg-gray-800 hover:bg-gray-700 border border-gray-700 text-gray-300 font-medium rounded-xl transition-colors text-sm flex items-center gap-2"
                  >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                    Re-analyze
                  </button>
                )}
              </div>

              {/* ── TEXT METADATA PANEL ── */}
              <div className="mt-4 border border-gray-700/60 rounded-xl overflow-hidden">
                <button
                  onClick={() => setMetaOpen(v => !v)}
                  className="w-full flex items-center justify-between px-4 py-3 bg-gray-800/40 hover:bg-gray-800/70 transition-colors text-left"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-sm">📋</span>
                    <span className="text-xs font-medium text-gray-300">Post metadata</span>
                    <span className="text-xs text-gray-600">title · description · hashtags</span>
                  </div>
                  <svg className={`w-3.5 h-3.5 text-gray-500 transition-transform ${metaOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                {metaOpen && (
                  <div className="p-4 space-y-4 bg-gray-900/40 border-t border-gray-700/60">
                    {result?.metaSuggestions && (
                      <p className="text-xs text-indigo-400 flex items-center gap-1.5">
                        <span>✨</span> AI suggestions ready — click <strong>Use</strong> to apply
                      </p>
                    )}
                    {PLATFORM_META_CONFIG[platform].showTitle && (
                      <MetaField
                        label={platform === 'youtube' ? '🎬 Video title' : '📌 Title'}
                        hint={platform === 'youtube' ? 'Under 60 chars for full display' : undefined}
                        value={textMeta.title}
                        onChange={v => setTextMeta(m => ({ ...m, title: v }))}
                        placeholder={platform === 'youtube' ? 'Your YouTube title here...' : 'Post title...'}
                        suggestion={result?.metaSuggestions?.title}
                        onUseSuggestion={v => setTextMeta(m => ({ ...m, title: v }))}
                      />
                    )}
                    <MetaField
                      label={PLATFORM_META_CONFIG[platform].captionLabel === 'Caption' ? '✏️ Caption' : '📝 Description'}
                      hint={platform === 'tiktok' ? 'Max 2,200 chars on TikTok' : platform === 'instagram' ? 'Max 2,200 chars, first 125 shown' : platform === 'youtube' ? 'First 200 chars show before "more"' : undefined}
                      value={textMeta.description}
                      onChange={v => setTextMeta(m => ({ ...m, description: v }))}
                      placeholder={platform === 'tiktok' || platform === 'instagram' ? 'Write your caption here...' : 'Describe your content...'}
                      rows={3}
                      suggestion={result?.metaSuggestions?.caption || result?.metaSuggestions?.description}
                      onUseSuggestion={v => setTextMeta(m => ({ ...m, description: v }))}
                    />
                    <div>
                      <MetaField
                        label="# Hashtags"
                        hint={PLATFORM_META_CONFIG[platform].hashtagTip}
                        value={textMeta.hashtags}
                        onChange={v => setTextMeta(m => ({ ...m, hashtags: v }))}
                        placeholder="#viral #fyp #content"
                        mono
                        suggestion={result?.metaSuggestions?.hashtags}
                        onUseSuggestion={v => setTextMeta(m => ({ ...m, hashtags: v }))}
                      />
                      {textMeta.hashtags && (
                        <p className="text-xs text-gray-600 mt-1">
                          {parseHashtags(textMeta.hashtags).length} hashtags
                          {platform === 'instagram' && ' · Instagram max 30'}
                          {platform === 'tiktok' && ' · TikTok sweet spot: 3–5'}
                          {platform === 'youtube' && ' · YouTube max 15 recommended'}
                        </p>
                      )}
                    </div>
                    {(textMeta.title || textMeta.description || textMeta.hashtags) && (
                      <button
                        onClick={copyAllMeta}
                        className="w-full text-xs text-gray-500 hover:text-emerald-400 transition-colors flex items-center justify-center gap-1.5 py-1"
                      >
                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                        Copy all metadata
                      </button>
                    )}
                  </div>
                )}
              </div>
            </>
          )}

          {/* IMAGE MODE */}
          {inputMode === 'image' && (
            <>
              <label className="block text-sm font-medium text-gray-300 mb-3">Upload thumbnail or image</label>

              {/* Drop zone */}
              <div
                onDragOver={e => { e.preventDefault(); setDragOver(true) }}
                onDragLeave={() => setDragOver(false)}
                onDrop={e => {
                  e.preventDefault()
                  setDragOver(false)
                  const file = e.dataTransfer.files[0]
                  if (file) handleImageFile(file)
                }}
                className={`relative rounded-xl border-2 border-dashed transition-all ${
                  dragOver
                    ? 'border-indigo-400 bg-indigo-500/10'
                    : 'border-gray-700 hover:border-gray-600'
                } ${imagePreview ? 'p-3' : 'p-8'}`}
              >
                {imagePreview ? (
                  <div className="relative">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={imagePreview}
                      alt="Preview"
                      className="w-full max-h-64 object-contain rounded-lg"
                    />
                    <button
                      onClick={() => { setImageFile(null); setImagePreview(null); setImageResult(null) }}
                      className="absolute top-2 right-2 w-7 h-7 bg-gray-900/80 hover:bg-gray-900 rounded-full flex items-center justify-center text-gray-400 hover:text-white transition-colors"
                    >
                      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                    <p className="text-xs text-gray-500 text-center mt-2">{imageFile?.name}</p>
                  </div>
                ) : (
                  <div className="text-center">
                    <div className="w-12 h-12 rounded-xl bg-gray-800 border border-gray-700 flex items-center justify-center mx-auto mb-3 text-xl">
                      🖼️
                    </div>
                    <p className="text-sm text-gray-300 font-medium mb-1">Drop your thumbnail here</p>
                    <p className="text-xs text-gray-500 mb-4">or click to browse — JPEG, PNG, WEBP up to 10MB</p>
                    <label className="inline-flex items-center gap-2 cursor-pointer bg-gray-800 hover:bg-gray-700 border border-gray-700 text-gray-300 text-sm font-medium px-4 py-2 rounded-lg transition-colors">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                      Browse files
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={e => { const f = e.target.files?.[0]; if (f) handleImageFile(f) }}
                      />
                    </label>
                  </div>
                )}
              </div>

              <div className="flex gap-3 mt-4">
                <button
                  onClick={handleAnalyzeImage}
                  disabled={loadingImage || !imageFile}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-medium py-3 rounded-xl transition-colors flex items-center justify-center gap-2 text-sm"
                >
                  {loadingImage ? (
                    <>
                      <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/>
                      </svg>
                      Rating thumbnail...
                    </>
                  ) : (
                    <>
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                      Rate thumbnail
                    </>
                  )}
                </button>
                {imageResult && (
                  <button
                    onClick={() => { setImageResult(null); setImageFile(null); setImagePreview(null) }}
                    className="px-4 py-3 bg-gray-800 hover:bg-gray-700 border border-gray-700 text-gray-300 font-medium rounded-xl transition-colors text-sm"
                  >
                    Clear
                  </button>
                )}
              </div>

              {/* ── IMAGE METADATA PANEL ── */}
              <div className="mt-4 border border-gray-700/60 rounded-xl overflow-hidden">
                <button
                  onClick={() => setMetaOpen(v => !v)}
                  className="w-full flex items-center justify-between px-4 py-3 bg-gray-800/40 hover:bg-gray-800/70 transition-colors text-left"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-sm">📋</span>
                    <span className="text-xs font-medium text-gray-300">Post metadata</span>
                    <span className="text-xs text-gray-600">caption · hashtags{platform === 'instagram' ? ' · alt text' : ''}</span>
                  </div>
                  <svg className={`w-3.5 h-3.5 text-gray-500 transition-transform ${metaOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                {metaOpen && (
                  <div className="p-4 space-y-4 bg-gray-900/40 border-t border-gray-700/60">
                    {imageResult?.metaSuggestions && (
                      <p className="text-xs text-indigo-400 flex items-center gap-1.5">
                        <span>✨</span> AI suggestions ready — click <strong>Use</strong> to apply
                      </p>
                    )}
                    <MetaField
                      label="✏️ Caption / Description"
                      hint={platform === 'instagram' ? 'First 125 chars show before "more"' : platform === 'tiktok' ? 'Max 2,200 chars' : undefined}
                      value={imageMeta.description}
                      onChange={v => setImageMeta(m => ({ ...m, description: v }))}
                      placeholder="Write your caption here..."
                      rows={3}
                      suggestion={imageResult?.metaSuggestions?.caption || imageResult?.metaSuggestions?.description}
                      onUseSuggestion={v => setImageMeta(m => ({ ...m, description: v }))}
                    />
                    {PLATFORM_META_CONFIG[platform ?? ''].showAltText && (
                      <MetaField
                        label="♿ Alt text"
                        hint="Accessibility + Instagram SEO"
                        value={imageMeta.altText}
                        onChange={v => setImageMeta(m => ({ ...m, altText: v }))}
                        placeholder="Describe the image for screen readers..."
                        suggestion={imageResult?.metaSuggestions?.altText}
                        onUseSuggestion={v => setImageMeta(m => ({ ...m, altText: v }))}
                      />
                    )}
                    <div>
                      <MetaField
                        label="# Hashtags"
                        hint={PLATFORM_META_CONFIG[platform ?? ''].hashtagTip}
                        value={imageMeta.hashtags}
                        onChange={v => setImageMeta(m => ({ ...m, hashtags: v }))}
                        placeholder="#photography #content #viral"
                        mono
                        suggestion={imageResult?.metaSuggestions?.hashtags}
                        onUseSuggestion={v => setImageMeta(m => ({ ...m, hashtags: v }))}
                      />
                      {imageMeta.hashtags && (
                        <p className="text-xs text-gray-600 mt-1">{parseHashtags(imageMeta.hashtags).length} hashtags</p>
                      )}
                    </div>
                    {(imageMeta.description || imageMeta.altText || imageMeta.hashtags) && (
                      <button
                        onClick={copyAllMeta}
                        className="w-full text-xs text-gray-500 hover:text-emerald-400 transition-colors flex items-center justify-center gap-1.5 py-1"
                      >
                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                        Copy all metadata
                      </button>
                    )}
                  </div>
                )}
              </div>
            </>
          )}

          {/* VIDEO MODE */}
          {inputMode === 'video' && (
            <>
              <label className="block text-sm font-medium text-gray-300 mb-1">Upload your video</label>
              <p className="text-xs text-gray-500 mb-3">MP4, MOV, or WEBM · max 25MB · AI will transcribe audio + rate the first frame</p>

              <div
                onDragOver={e => { e.preventDefault(); setVideoDragOver(true) }}
                onDragLeave={() => setVideoDragOver(false)}
                onDrop={e => {
                  e.preventDefault()
                  setVideoDragOver(false)
                  const file = e.dataTransfer.files[0]
                  if (file) handleVideoFile(file)
                }}
                className={`relative rounded-xl border-2 border-dashed transition-all ${
                  videoDragOver
                    ? 'border-indigo-400 bg-indigo-500/10'
                    : 'border-gray-700 hover:border-gray-600'
                } ${videoPreview ? 'p-3' : 'p-8'}`}
              >
                {videoPreview ? (
                  <div className="relative">
                    <video
                      src={videoPreview}
                      className="w-full max-h-48 rounded-lg object-contain bg-black"
                      controls
                      muted
                    />
                    <button
                      onClick={() => { setVideoFile(null); setVideoPreview(null); setVideoResult(null) }}
                      className="absolute top-2 right-2 w-7 h-7 bg-gray-900/80 hover:bg-gray-900 rounded-full flex items-center justify-center text-gray-400 hover:text-white transition-colors"
                    >
                      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                    <p className="text-xs text-gray-500 text-center mt-2">{videoFile?.name} · {videoFile ? (videoFile.size / 1024 / 1024).toFixed(1) : 0}MB</p>
                  </div>
                ) : (
                  <div className="text-center">
                    <div className="w-12 h-12 rounded-xl bg-gray-800 border border-gray-700 flex items-center justify-center mx-auto mb-3 text-xl">
                      🎬
                    </div>
                    <p className="text-sm text-gray-300 font-medium mb-1">Drop your video here</p>
                    <p className="text-xs text-gray-500 mb-4">TikTok, Reel, Short — any short-form video</p>
                    <label className="inline-flex items-center gap-2 cursor-pointer bg-gray-800 hover:bg-gray-700 border border-gray-700 text-gray-300 text-sm font-medium px-4 py-2 rounded-lg transition-colors">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15 10l4.553-2.069A1 1 0 0121 8.869v6.262a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                      </svg>
                      Choose video
                      <input
                        type="file"
                        accept="video/*"
                        className="hidden"
                        onChange={e => { const f = e.target.files?.[0]; if (f) handleVideoFile(f) }}
                      />
                    </label>
                  </div>
                )}
              </div>

              <div className="flex gap-3 mt-4">
                <button
                  onClick={handleAnalyzeVideo}
                  disabled={loadingVideo || !videoFile}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-medium py-3 rounded-xl transition-colors flex items-center justify-center gap-2 text-sm"
                >
                  {loadingVideo ? (
                    <>
                      <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/>
                      </svg>
                      {videoProgress || 'Analyzing...'}
                    </>
                  ) : (
                    <>
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                      Analyze video
                    </>
                  )}
                </button>
                {videoResult && (
                  <button
                    onClick={() => { setVideoResult(null); setVideoFile(null); setVideoPreview(null) }}
                    className="px-4 py-3 bg-gray-800 hover:bg-gray-700 border border-gray-700 text-gray-300 font-medium rounded-xl transition-colors text-sm"
                  >
                    Clear
                  </button>
                )}
              </div>

              {/* ── VIDEO METADATA PANEL ── */}
              <div className="mt-4 border border-gray-700/60 rounded-xl overflow-hidden">
                <button
                  onClick={() => setMetaOpen(v => !v)}
                  className="w-full flex items-center justify-between px-4 py-3 bg-gray-800/40 hover:bg-gray-800/70 transition-colors text-left"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-sm">📋</span>
                    <span className="text-xs font-medium text-gray-300">Post metadata</span>
                    <span className="text-xs text-gray-600">
                      {platform === 'youtube' ? 'title · description · thumbnail text · hashtags' : 'caption · description · hashtags'}
                    </span>
                  </div>
                  <svg className={`w-3.5 h-3.5 text-gray-500 transition-transform ${metaOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                {metaOpen && (
                  <div className="p-4 space-y-4 bg-gray-900/40 border-t border-gray-700/60">
                    {videoResult?.metaSuggestions && (
                      <p className="text-xs text-indigo-400 flex items-center gap-1.5">
                        <span>✨</span> AI suggestions ready — click <strong>Use</strong> to apply
                      </p>
                    )}
                    {PLATFORM_META_CONFIG[platform ?? ''].showTitle && (
                      <MetaField
                        label="🎬 Title"
                        hint={platform === 'youtube' ? 'Under 60 chars · appears in search results' : undefined}
                        value={videoMeta.title}
                        onChange={v => setVideoMeta(m => ({ ...m, title: v }))}
                        placeholder="Your video title..."
                        suggestion={videoResult?.metaSuggestions?.title}
                        onUseSuggestion={v => setVideoMeta(m => ({ ...m, title: v }))}
                      />
                    )}

                    {platform !== 'youtube' && (
                      <MetaField
                        label="✏️ Caption"
                        hint={platform === 'tiktok' ? 'Goes below video · max 2,200 chars' : platform === 'instagram' ? 'First 125 chars show before "more"' : undefined}
                        value={videoMeta.caption}
                        onChange={v => setVideoMeta(m => ({ ...m, caption: v }))}
                        placeholder={platform === 'tiktok' ? 'TikTok caption here...' : 'Caption / post text...'}
                        rows={2}
                        suggestion={videoResult?.metaSuggestions?.caption}
                        onUseSuggestion={v => setVideoMeta(m => ({ ...m, caption: v }))}
                      />
                    )}

                    <MetaField
                      label={platform === 'youtube' ? '📝 Description' : '📝 Extended description'}
                      hint={platform === 'youtube' ? 'First 200 chars show before "more" · add links here' : 'Extra context, links, or call to action'}
                      value={videoMeta.description}
                      onChange={v => setVideoMeta(m => ({ ...m, description: v }))}
                      placeholder={platform === 'youtube' ? 'Full video description, links, chapters...' : 'Additional description, links...'}
                      rows={3}
                      suggestion={videoResult?.metaSuggestions?.description}
                      onUseSuggestion={v => setVideoMeta(m => ({ ...m, description: v }))}
                    />

                    {PLATFORM_META_CONFIG[platform ?? ''].showThumbnailText && (
                      <MetaField
                        label="🖼️ Thumbnail overlay text"
                        hint="Big bold text on thumbnail · under 6 words works best"
                        value={videoMeta.thumbnailText}
                        onChange={v => setVideoMeta(m => ({ ...m, thumbnailText: v }))}
                        placeholder="e.g. I tried this for 30 days..."
                        suggestion={videoResult?.metaSuggestions?.thumbnailText}
                        onUseSuggestion={v => setVideoMeta(m => ({ ...m, thumbnailText: v }))}
                      />
                    )}

                    <div>
                      <MetaField
                        label="# Hashtags / Tags"
                        hint={PLATFORM_META_CONFIG[platform ?? ''].hashtagTip}
                        value={videoMeta.hashtags}
                        onChange={v => setVideoMeta(m => ({ ...m, hashtags: v }))}
                        placeholder={platform === 'youtube' ? '#shorts #topic #niche' : '#fyp #viral #topic'}
                        mono
                        suggestion={videoResult?.metaSuggestions?.hashtags}
                        onUseSuggestion={v => setVideoMeta(m => ({ ...m, hashtags: v }))}
                      />
                      {videoMeta.hashtags && (
                        <p className="text-xs text-gray-600 mt-1">{parseHashtags(videoMeta.hashtags).length} hashtags</p>
                      )}
                    </div>

                    {(videoMeta.title || videoMeta.caption || videoMeta.description || videoMeta.thumbnailText || videoMeta.hashtags) && (
                      <button
                        onClick={copyAllMeta}
                        className="w-full text-xs text-gray-500 hover:text-emerald-400 transition-colors flex items-center justify-center gap-1.5 py-1"
                      >
                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                        Copy all metadata
                      </button>
                    )}
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        {/* ── IMAGE RESULTS ── */}
        {imageResult && inputMode === 'image' && !loadingImage && (
          <div className="space-y-5 animate-slide-up">

            {/* Score + summary */}
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6 flex flex-col sm:flex-row gap-6 items-center sm:items-start">
              <ScoreGauge score={imageResult.thumbnailScore} />
              <div className="flex-1">
                <h2 className="text-lg font-semibold text-white mb-2">Thumbnail Rating</h2>
                <p className="text-gray-400 text-sm leading-relaxed">{imageResult.summary}</p>
              </div>
            </div>

            {/* Metrics */}
            <div>
              <h2 className="text-base font-semibold text-white mb-3">Visual metrics</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {METRICS.map(m => (
                  <MetricCard key={m.key} label={m.label} value={imageResult[m.key as keyof ImageAnalysisResult] as number} description={m.description} />
                ))}
              </div>
            </div>

            {/* Visual feedback cards */}
            <div className="grid sm:grid-cols-3 gap-4">
              {[
                { icon: '🎨', label: 'Color & Contrast', text: imageResult.colorFeedback },
                { icon: '✏️', label: 'Text Overlay', text: imageResult.textOverlayFeedback },
                { icon: '😊', label: 'Face & Emotion', text: imageResult.faceFeedback },
              ].map(fb => (
                <div key={fb.label} className="bg-gray-900 border border-gray-800 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span>{fb.icon}</span>
                    <p className="text-xs font-semibold text-gray-300">{fb.label}</p>
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed">{fb.text}</p>
                </div>
              ))}
            </div>

            {/* Suggestions */}
            <div>
              <h2 className="text-base font-semibold text-white mb-3">Improvement suggestions</h2>
              <SuggestionList suggestions={imageResult.suggestions} onCopy={copyToClipboard} />
            </div>
          </div>
        )}

        {/* ── LOADING (image) ── */}
        {loadingImage && <AnalysisSkeleton />}

        {/* ── LOADING (video) ── */}
        {loadingVideo && (
          <div className="space-y-3">
            <AnalysisSkeleton />
            {videoProgress && (
              <p className="text-center text-xs text-indigo-400 animate-pulse">{videoProgress}</p>
            )}
          </div>
        )}

        {/* ── VIDEO RESULTS ── */}
        {videoResult && inputMode === 'video' && !loadingVideo && (
          <div className="space-y-5 animate-slide-up">

            {/* Transcript */}
            {videoResult.hasTranscript && (
              <div className="bg-gray-900 rounded-2xl border border-gray-800 p-5">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-base">📝</span>
                  <h2 className="text-sm font-semibold text-white">Transcript</h2>
                  <span className="text-xs bg-green-500/10 text-green-400 border border-green-500/20 px-2 py-0.5 rounded-full">Whisper AI</span>
                </div>
                <p className="text-xs text-gray-400 leading-relaxed line-clamp-4">{videoResult.transcript}</p>
              </div>
            )}

            {!videoResult.hasTranscript && (
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4">
                <p className="text-xs text-amber-400 font-medium mb-1">⚠️ No speech detected</p>
                <p className="text-xs text-gray-400">The video may be silent or music-only. Visual analysis still applied.</p>
              </div>
            )}

            {/* Dual scores */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5 flex flex-col items-center gap-2">
                <p className="text-xs text-gray-500 font-medium">Content Score</p>
                <ScoreGauge score={videoResult.viralScore} />
                <p className="text-xs text-gray-500 text-center leading-relaxed">{videoResult.summary}</p>
              </div>
              <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5 flex flex-col items-center gap-2">
                <p className="text-xs text-gray-500 font-medium">Thumbnail Score</p>
                <ScoreGauge score={videoResult.thumbnailScore} />
                <p className="text-xs text-gray-500 text-center">{videoResult.colorFeedback}</p>
              </div>
            </div>

            {/* Metrics */}
            <div>
              <h2 className="text-base font-semibold text-white mb-3">Content metrics</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {METRICS.map(m => (
                  <MetricCard key={m.key} label={m.label} value={videoResult[m.key as keyof VideoAnalysisResult] as number} description={m.description} />
                ))}
              </div>
            </div>

            {/* Visual feedback */}
            <div>
              <h2 className="text-base font-semibold text-white mb-3">Visual analysis</h2>
              <div className="grid sm:grid-cols-3 gap-4">
                {[
                  { icon: '🎨', label: 'Color & Contrast', text: videoResult.colorFeedback },
                  { icon: '✏️', label: 'Text Overlay', text: videoResult.textOverlayFeedback },
                  { icon: '😊', label: 'Face & Emotion', text: videoResult.faceFeedback },
                ].map(fb => (
                  <div key={fb.label} className="bg-gray-900 border border-gray-800 rounded-xl p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <span>{fb.icon}</span>
                      <p className="text-xs font-semibold text-gray-300">{fb.label}</p>
                    </div>
                    <p className="text-xs text-gray-400 leading-relaxed">{fb.text}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Hook analyzer */}
            {videoResult.hookDiagnosis && (
              <div className="bg-gray-900 rounded-2xl border border-indigo-500/40 p-5">
                <div className="flex items-center gap-2 mb-3 flex-wrap">
                  <span className="text-lg">🪝</span>
                  <h2 className="text-sm font-semibold text-white">Hook Analyzer</h2>
                  {videoResult.hookType && (
                    <span className={`text-xs px-2.5 py-0.5 rounded-full border font-medium ${
                      HOOK_TYPE_COLORS[videoResult.hookType] ?? 'bg-gray-700 text-gray-300 border-gray-600'
                    }`}>
                      {videoResult.hookType}
                    </span>
                  )}
                </div>
                <div className="grid sm:grid-cols-3 gap-4">
                  <div className="bg-gray-800/40 rounded-xl p-4 flex flex-col items-center justify-center text-center">
                    <p className="text-xs text-gray-500 mb-1 font-medium">Hook Score</p>
                    <p className={`text-4xl font-bold ${hookScoreColor(videoResult.hookScore ?? 0)}`}>
                      {videoResult.hookScore ?? '—'}<span className="text-xl text-gray-500">/10</span>
                    </p>
                  </div>
                  <div className="sm:col-span-2 bg-gray-800/40 rounded-xl p-4">
                    <p className="text-xs text-gray-500 mb-1.5 font-medium">Diagnosis</p>
                    <p className="text-sm text-gray-300 leading-relaxed">{videoResult.hookDiagnosis}</p>
                  </div>
                </div>
                {videoResult.rewrittenHook && (
                  <div className="mt-4 bg-indigo-950/50 border border-indigo-500/25 rounded-xl p-4">
                    <p className="text-xs text-gray-500 mb-1.5">Suggested opening line rewrite</p>
                    <p className="text-sm text-indigo-200 font-medium leading-relaxed">{videoResult.rewrittenHook}</p>
                  </div>
                )}
              </div>
            )}

            {/* All suggestions combined */}
            <div>
              <h2 className="text-base font-semibold text-white mb-3">Improvement suggestions</h2>
              <SuggestionList
                suggestions={[...videoResult.suggestions, ...(videoResult.thumbnailSuggestions ?? [])]}
                onCopy={copyToClipboard}
              />
            </div>
          </div>
        )}

        {/* ── LOADING (text) ── */}
        {loading && inputMode === 'text' && <AnalysisSkeleton />}

        {result && !loading && inputMode === 'text' && (
          <div className="space-y-6 animate-slide-up">

            {/* Score + verdict */}
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6 flex flex-col sm:flex-row gap-6 items-center sm:items-start">
              <ScoreGauge score={result.viralScore} />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2 flex-wrap">
                  <h2 className="text-lg font-semibold text-white">Verdict</h2>
                  {platform && (
                    <span className="text-xs bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 px-2 py-0.5 rounded-full">
                      {PLATFORM_ICONS[platform]} {PLATFORM_LABELS[platform]}
                    </span>
                  )}
                </div>
                <p className="text-gray-400 text-sm leading-relaxed">{result.summary}</p>
              </div>
            </div>

            {/* ── HOOK ANALYZER ── */}
            <div className="bg-gray-900 rounded-2xl border border-indigo-500/40 p-6">
              <div className="flex items-center gap-2 mb-4 flex-wrap">
                <span className="text-lg">🪝</span>
                <h2 className="text-base font-semibold text-white">Hook Analyzer</h2>
                {result.hookType && (
                  <span className={`text-xs px-2.5 py-0.5 rounded-full border font-medium ${
                    HOOK_TYPE_COLORS[result.hookType] ?? 'bg-gray-700 text-gray-300 border-gray-600'
                  }`}>
                    {result.hookType}
                  </span>
                )}
              </div>

              {/* Opening hook quote */}
              <div className="bg-gray-800/60 border border-gray-700 rounded-xl p-4 mb-4">
                <p className="text-xs text-gray-500 mb-1.5 font-medium uppercase tracking-wide">Your opening hook</p>
                <p className="text-sm text-white leading-relaxed font-medium italic">
                  &ldquo;{originalContent.split('\n')[0].substring(0, 200)}&rdquo;
                </p>
              </div>

              <div className="grid sm:grid-cols-3 gap-4">
                {/* Score circle */}
                <div className="bg-gray-800/40 rounded-xl p-4 flex flex-col items-center justify-center text-center">
                  <p className="text-xs text-gray-500 mb-1 font-medium">Hook Score</p>
                  <p className={`text-4xl font-bold ${hookScoreColor(result.hookScore ?? 0)}`}>
                    {result.hookScore ?? '—'}
                    <span className="text-xl text-gray-500">/10</span>
                  </p>
                </div>
                {/* Diagnosis */}
                <div className="sm:col-span-2 bg-gray-800/40 rounded-xl p-4">
                  <p className="text-xs text-gray-500 mb-1.5 font-medium">Diagnosis</p>
                  <p className="text-sm text-gray-300 leading-relaxed">{result.hookDiagnosis ?? '—'}</p>
                </div>
              </div>

              {/* Rewritten hook */}
              {result.rewrittenHook && (
                <div className="mt-4">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs text-gray-500 font-medium">Suggested rewrite</p>
                    <button
                      onClick={() => copyToClipboard(result.rewrittenHook, 'Rewritten hook')}
                      className="flex items-center gap-1 text-xs text-gray-500 hover:text-indigo-400 transition-colors"
                    >
                      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                      </svg>
                      Copy
                    </button>
                  </div>
                  <div className="bg-indigo-950/50 border border-indigo-500/25 rounded-xl p-4">
                    <p className="text-sm text-indigo-200 font-medium leading-relaxed">{result.rewrittenHook}</p>
                  </div>
                </div>
              )}
            </div>

            {/* Metrics */}
            <div>
              <h2 className="text-base font-semibold text-white mb-3">Metric breakdown</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {METRICS.map(m => (
                  <MetricCard key={m.key} label={m.label} value={result[m.key]} description={m.description} />
                ))}
              </div>
            </div>

            {/* Hook comparison (before/after) */}
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-base font-semibold text-white">Hook comparison</h2>
                <button
                  onClick={() => copyToClipboard(result.rewrittenHook, 'Rewritten hook')}
                  className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-indigo-400 transition-colors"
                >
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                  Copy improved
                </button>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="bg-gray-800/60 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-2 h-2 rounded-full bg-red-400 flex-shrink-0" />
                    <p className="text-xs font-medium text-gray-500">Original</p>
                  </div>
                  <p className="text-sm text-gray-400 leading-relaxed line-through opacity-70">
                    {originalContent.split('\n')[0]}
                  </p>
                </div>
                <div className="bg-indigo-950/40 border border-indigo-500/20 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-2 h-2 rounded-full bg-green-400 flex-shrink-0" />
                    <p className="text-xs font-medium text-indigo-400">Improved</p>
                  </div>
                  <p className="text-sm text-indigo-200 font-medium leading-relaxed">
                    {result.rewrittenHook}
                  </p>
                </div>
              </div>
            </div>

            {/* Suggestions */}
            <div>
              <h2 className="text-base font-semibold text-white mb-3">Improvement suggestions</h2>
              <SuggestionList suggestions={result.suggestions} onCopy={copyToClipboard} />
            </div>

            {/* Caption generator */}
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6">
              <div className="flex items-center justify-between mb-1">
                <h2 className="text-base font-semibold text-white">Caption generator</h2>
                <span className="text-xs text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-2 py-0.5 rounded-full">AI co-creation</span>
              </div>
              <p className="text-xs text-gray-500 mb-4">Generate 3 alternative captions with different angles</p>

              {captions.length === 0 && !loadingCaptions && (
                <button
                  onClick={handleGenerateCaptions}
                  className="w-full border border-dashed border-indigo-500/40 hover:border-indigo-500/70 text-indigo-400 hover:text-indigo-300 rounded-xl py-3 text-sm font-medium transition-all flex items-center justify-center gap-2"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                  Generate alternative captions
                </button>
              )}

              {loadingCaptions && (
                <div className="space-y-3 animate-pulse">
                  {[0, 1, 2].map(i => (
                    <div key={i} className="bg-gray-800 rounded-xl border border-gray-700 p-4 space-y-2">
                      <div className="h-3 w-24 bg-gray-700 rounded" />
                      <div className="h-4 w-full bg-gray-700 rounded" />
                      <div className="h-4 w-4/5 bg-gray-700 rounded" />
                    </div>
                  ))}
                </div>
              )}

              {captions.length > 0 && (
                <div className="space-y-3">
                  {captions.map((cap, i) => (
                    <div key={i} className="bg-gray-800 rounded-xl border border-gray-700 p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-semibold text-indigo-400">{cap.style}</span>
                        <button
                          onClick={() => copyToClipboard(cap.text, cap.style)}
                          className="text-xs text-gray-500 hover:text-indigo-400 transition-colors flex items-center gap-1"
                        >
                          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                          </svg>
                          Copy
                        </button>
                      </div>
                      <p className="text-sm text-gray-300 leading-relaxed">{cap.text}</p>
                    </div>
                  ))}
                  <button
                    onClick={handleGenerateCaptions}
                    className="text-xs text-gray-500 hover:text-gray-300 transition-colors flex items-center gap-1.5"
                  >
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                    Regenerate
                  </button>
                </div>
              )}
            </div>

            {/* ── GROWTH TOOLKIT ── */}
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6">
              <div className="flex items-center justify-between mb-1">
                <h2 className="text-base font-semibold text-white flex items-center gap-2">
                  🚀 Growth Toolkit
                </h2>
                <span className="text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                  Auto-generated
                </span>
              </div>
              <p className="text-xs text-gray-500 mb-5">Hashtags and audio pairings tailored to your content</p>

              {loadingToolkit && (
                <div className="space-y-4 animate-pulse">
                  <div>
                    <div className="h-3 w-20 bg-gray-800 rounded mb-3" />
                    <div className="flex flex-wrap gap-2">
                      {Array.from({ length: 8 }).map((_, i) => (
                        <div key={i} className="h-7 w-24 bg-gray-800 rounded-full" />
                      ))}
                    </div>
                  </div>
                  <div className="space-y-2">
                    {[0, 1, 2].map(i => <div key={i} className="h-16 bg-gray-800 rounded-xl" />)}
                  </div>
                </div>
              )}

              {toolkit && !loadingToolkit && (
                <div className="space-y-6">
                  {/* Hashtags */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-sm font-medium text-gray-300">Hashtags</h3>
                      <button
                        onClick={() => copyToClipboard(toolkit.hashtags.join(' '), 'All hashtags')}
                        className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-emerald-400 transition-colors"
                      >
                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                        Copy all
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {toolkit.hashtags.map((tag, i) => (
                        <button
                          key={i}
                          onClick={() => copyToClipboard(tag, tag)}
                          className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 border border-gray-700 hover:border-emerald-500/40 text-sm text-emerald-400 rounded-full transition-all font-mono"
                        >
                          {tag}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Audio suggestions */}
                  <div>
                    <h3 className="text-sm font-medium text-gray-300 mb-3">Trending Audio Styles</h3>
                    <div className="space-y-3">
                      {toolkit.audioSuggestions.map((audio, i) => (
                        <div key={i} className="bg-gray-800/60 rounded-xl p-4 border border-gray-700 flex items-start gap-3">
                          <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-sm">
                            🎵
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2 mb-1">
                              <p className="text-sm font-semibold text-white">{audio.style}</p>
                              <button
                                onClick={() => copyToClipboard(audio.style, audio.style)}
                                className="flex-shrink-0 text-xs text-gray-600 hover:text-indigo-400 transition-colors"
                              >
                                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                                </svg>
                              </button>
                            </div>
                            <p className="text-xs text-gray-400 leading-relaxed">{audio.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {!toolkit && !loadingToolkit && (
                <button
                  onClick={() => fetchToolkit(originalContent, platform)}
                  className="w-full border border-dashed border-emerald-500/40 hover:border-emerald-500/70 text-emerald-400 hover:text-emerald-300 rounded-xl py-3 text-sm font-medium transition-all flex items-center justify-center gap-2"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                  </svg>
                  Generate growth toolkit
                </button>
              )}
            </div>


            {/* ── COMPETITOR COMPARISON ── */}
            <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6">
              <button
                onClick={() => { setCompareOpen(v => !v); setCompareResult(null) }}
                className="w-full flex items-center justify-between group"
              >
                <div className="flex items-center gap-2">
                  <span className="text-lg">⚔️</span>
                  <h2 className="text-base font-semibold text-white">Compare with competitor</h2>
                </div>
                <svg
                  className={`w-4 h-4 text-gray-500 transition-transform ${compareOpen ? 'rotate-180' : ''}`}
                  fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}
                >
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {compareOpen && (
                <div className="mt-5 space-y-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-400 mb-2">Paste competitor content</label>
                    <textarea
                      value={competitorContent}
                      onChange={e => setCompetitorContent(e.target.value)}
                      placeholder="Paste their caption, script, or hook here..."
                      rows={4}
                      className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition-colors resize-none text-sm leading-relaxed"
                    />
                  </div>
                  <button
                    onClick={handleCompare}
                    disabled={loadingCompare || competitorContent.trim().length < 10}
                    className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-medium py-2.5 rounded-xl transition-colors flex items-center justify-center gap-2 text-sm"
                  >
                    {loadingCompare ? (
                      <>
                        <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/>
                        </svg>
                        Comparing...
                      </>
                    ) : 'Compare content'}
                  </button>

                  {compareResult && (
                    <div className="space-y-5 pt-2">
                      {/* Side-by-side scores */}
                      <div className="grid grid-cols-2 gap-3">
                        {/* Yours */}
                        <div className="bg-gray-800/60 border border-gray-700 rounded-xl p-4 text-center">
                          <p className="text-xs text-gray-500 mb-1 font-medium">Your content</p>
                          <p className={`text-4xl font-bold ${
                            compareResult.yours.viralScore >= compareResult.theirs.viralScore
                              ? 'text-green-400' : 'text-red-400'
                          }`}>
                            {compareResult.yours.viralScore}
                          </p>
                          <p className="text-xs text-gray-500 mt-0.5">/ 100</p>
                        </div>
                        {/* Theirs */}
                        <div className="bg-gray-800/60 border border-gray-700 rounded-xl p-4 text-center">
                          <p className="text-xs text-gray-500 mb-1 font-medium">Competitor</p>
                          <p className={`text-4xl font-bold ${
                            compareResult.theirs.viralScore > compareResult.yours.viralScore
                              ? 'text-green-400' : 'text-red-400'
                          }`}>
                            {compareResult.theirs.viralScore}
                          </p>
                          <p className="text-xs text-gray-500 mt-0.5">/ 100</p>
                        </div>
                      </div>

                      {/* Metric diffs */}
                      <div className="space-y-2">
                        {(
                          [
                            { key: 'hookStrength', label: 'Hook Strength' },
                            { key: 'emotionalEngagement', label: 'Emotional Engagement' },
                            { key: 'clarity', label: 'Clarity' },
                            { key: 'retentionPotential', label: 'Retention Potential' },
                          ] as const
                        ).map(({ key, label }) => {
                          const mine = compareResult.yours[key]
                          const theirs = compareResult.theirs[key]
                          const diff = mine - theirs
                          return (
                            <div key={key} className="flex items-center gap-2 sm:gap-3">
                              <p className="text-xs text-gray-400 w-24 sm:w-40 flex-shrink-0 truncate">{label}</p>
                              <div className="flex-1 grid grid-cols-2 gap-2">
                                <div className="bg-gray-800 rounded-lg h-7 relative overflow-hidden">
                                  <div
                                    className="absolute inset-y-0 left-0 bg-indigo-600/50 rounded-lg transition-all"
                                    style={{ width: `${mine * 10}%` }}
                                  />
                                  <span className="absolute inset-0 flex items-center justify-center text-xs font-medium text-white">
                                    {mine}/10
                                  </span>
                                </div>
                                <div className="bg-gray-800 rounded-lg h-7 relative overflow-hidden">
                                  <div
                                    className="absolute inset-y-0 left-0 bg-gray-600/50 rounded-lg transition-all"
                                    style={{ width: `${theirs * 10}%` }}
                                  />
                                  <span className="absolute inset-0 flex items-center justify-center text-xs font-medium text-white">
                                    {theirs}/10
                                  </span>
                                </div>
                              </div>
                              <div className={`text-xs font-bold w-10 text-right flex-shrink-0 ${
                                diff > 0 ? 'text-green-400' : diff < 0 ? 'text-red-400' : 'text-gray-500'
                              }`}>
                                {diff > 0 ? `+${diff}` : diff < 0 ? `${diff}` : '='}
                              </div>
                            </div>
                          )
                        })}
                      </div>

                      {/* Better summary */}
                      <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4">
                        <p className="text-xs font-semibold text-amber-400 mb-2">
                          {compareResult.theirs.viralScore > compareResult.yours.viralScore
                            ? '📊 What they are doing better'
                            : '🏆 What you are doing better'}
                        </p>
                        <p className="text-sm text-gray-300 leading-relaxed">{compareResult.betterSummary}</p>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="text-center">
              <a href="/history" className="text-xs text-gray-600 hover:text-indigo-400 transition-colors">
                View full analysis history →
              </a>
            </div>
          </div>
        )}

        {/* ── EMPTY / RECENT ── */}
        {!result && !loading && inputMode === 'text' && (
          recentAnalyses.length === 0 ? (
            <EmptyState />
          ) : (
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-base font-semibold text-white">Recent analyses</h2>
                <a href="/history" className="text-xs text-indigo-400 hover:text-indigo-300 transition-colors">View all →</a>
              </div>
              <div className="space-y-2">
                {recentAnalyses.map(a => (
                  <div
                    key={a.id}
                    onClick={() => loadHistoricResult(a)}
                    className="bg-gray-900 border border-gray-800 rounded-xl p-4 cursor-pointer hover:border-gray-600 transition-all flex items-center gap-4 group"
                  >
                    <div className={`flex-shrink-0 w-12 h-12 rounded-xl border flex flex-col items-center justify-center text-xs font-bold ${
                      a.result.viralScore >= 75
                        ? 'bg-green-500/10 border-green-500/20 text-green-400'
                        : a.result.viralScore >= 50
                        ? 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400'
                        : 'bg-red-500/10 border-red-500/20 text-red-400'
                    }`}>
                      {a.result.viralScore}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <p className="text-sm text-gray-400 truncate">{a.content}</p>
                        {a.platform && (
                          <span className="flex-shrink-0 text-xs">
                            {PLATFORM_ICONS[a.platform as Platform]}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-600">{new Date(a.created_at).toLocaleDateString()}</p>
                    </div>
                    <svg className="w-4 h-4 text-gray-700 group-hover:text-gray-500 flex-shrink-0 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                ))}
              </div>
            </div>
          )
        )}
      </div>
    </>
  )
}
