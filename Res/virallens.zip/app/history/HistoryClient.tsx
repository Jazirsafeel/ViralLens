'use client'

import { useState, useMemo } from 'react'
import { Analysis, AnalysisResult, Platform, PLATFORM_LABELS } from '@/types'

const PLATFORM_ICONS: Record<Platform, string> = {
  tiktok: '🎵',
  instagram: '📸',
  youtube: '▶️',
}
import ScoreGauge from '@/components/ScoreGauge'
import MetricCard from '@/components/MetricCard'
import SuggestionList from '@/components/SuggestionList'
import { ToastContainer, useToast } from '@/components/Toast'

const PAGE_SIZE = 10

const METRICS = [
  { key: 'hookStrength', label: 'Hook Strength', description: 'How compelling is the opening?' },
  { key: 'emotionalEngagement', label: 'Emotional Engagement', description: 'Emotional response trigger?' },
  { key: 'clarity', label: 'Clarity', description: 'Is the message clear?' },
  { key: 'retentionPotential', label: 'Retention Potential', description: 'Will they stick around?' },
] as const

interface Props {
  analyses: Analysis[]
}

export default function HistoryClient({ analyses: initial }: Props) {
  const [analyses, setAnalyses] = useState<Analysis[]>(initial)
  const [selected, setSelected] = useState<Analysis | null>(null)
  const [search, setSearch] = useState('')
  const [scoreFilter, setScoreFilter] = useState<'all' | 'high' | 'mid' | 'low'>('all')
  const [dateFilter, setDateFilter] = useState('')
  const [page, setPage] = useState(1)
  const [deleting, setDeleting] = useState<string | null>(null)
  const { toasts, addToast, removeToast } = useToast()

  const filtered = useMemo(() => {
    return analyses.filter(a => {
      const score = a.result.viralScore
      if (search && !a.content.toLowerCase().includes(search.toLowerCase())) return false
      if (scoreFilter === 'high' && score < 75) return false
      if (scoreFilter === 'mid' && (score < 50 || score >= 75)) return false
      if (scoreFilter === 'low' && score >= 50) return false
      if (dateFilter) {
        const created = new Date(a.created_at).toISOString().slice(0, 10)
        if (created !== dateFilter) return false
      }
      return true
    })
  }, [analyses, search, scoreFilter, dateFilter])

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE)

  async function handleDelete(id: string) {
    setDeleting(id)
    try {
      const res = await fetch(`/api/analyses/${id}`, { method: 'DELETE' })
      if (res.ok) {
        setAnalyses(prev => prev.filter(a => a.id !== id))
        if (selected?.id === id) setSelected(null)
        addToast('Analysis deleted', 'success')
      } else {
        addToast('Failed to delete', 'error')
      }
    } catch {
      addToast('Failed to delete', 'error')
    }
    setDeleting(null)
  }

  function scoreColor(s: number) {
    return s >= 75 ? 'text-green-400' : s >= 50 ? 'text-yellow-400' : 'text-red-400'
  }
  function scoreLabel(s: number) {
    return s >= 75 ? 'High' : s >= 50 ? 'Mid' : 'Low'
  }
  function scoreBadge(s: number) {
    return s >= 75
      ? 'bg-green-500/10 border-green-500/20 text-green-400'
      : s >= 50
      ? 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400'
      : 'bg-red-500/10 border-red-500/20 text-red-400'
  }

  return (
    <>
      <ToastContainer toasts={toasts} onRemove={removeToast} />

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Left: list */}
        <div className="flex-1 min-w-0">
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-3 mb-4">
            <input
              type="text"
              placeholder="Search content..."
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1) }}
              className="flex-1 bg-gray-900 border border-gray-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
            <select
              value={scoreFilter}
              onChange={e => { setScoreFilter(e.target.value as typeof scoreFilter); setPage(1) }}
              className="bg-gray-900 border border-gray-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500 transition-colors"
            >
              <option value="all">All scores</option>
              <option value="high">High (≥75)</option>
              <option value="mid">Mid (50–74)</option>
              <option value="low">Low (&lt;50)</option>
            </select>
            <input
              type="date"
              value={dateFilter}
              onChange={e => { setDateFilter(e.target.value); setPage(1) }}
              className="bg-gray-900 border border-gray-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          {/* Count */}
          <p className="text-xs text-gray-500 mb-3">
            {filtered.length} {filtered.length === 1 ? 'result' : 'results'}
          </p>

          {/* List */}
          {filtered.length === 0 ? (
            <div className="text-center py-16 text-gray-500 text-sm">
              No analyses match your filters.
            </div>
          ) : (
            <div className="space-y-2 animate-fade-in">
              {paginated.map(a => (
                <div
                  key={a.id}
                  onClick={() => setSelected(a)}
                  className={`group bg-gray-900 border rounded-xl p-4 cursor-pointer transition-all flex items-start gap-4 ${
                    selected?.id === a.id ? 'border-indigo-500/50 bg-indigo-950/20' : 'border-gray-800 hover:border-gray-600'
                  }`}
                >
                  {/* Score badge */}
                  <div className={`flex-shrink-0 w-14 h-14 rounded-xl border flex flex-col items-center justify-center ${scoreBadge(a.result.viralScore)}`}>
                    <span className="text-lg font-bold leading-none">{a.result.viralScore}</span>
                    <span className="text-[10px] mt-0.5">{scoreLabel(a.result.viralScore)}</span>
                  </div>

                  {/* Content preview */}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-300 truncate">{a.content}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <p className="text-xs text-gray-600">{new Date(a.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
                      {a.platform && (
                        <span className="text-xs text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-1.5 py-0.5 rounded-full">
                          {PLATFORM_ICONS[a.platform as Platform]} {PLATFORM_LABELS[a.platform as Platform]}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Delete button */}
                  <button
                    onClick={e => { e.stopPropagation(); handleDelete(a.id) }}
                    disabled={deleting === a.id}
                    className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity text-gray-600 hover:text-red-400 p-1 rounded disabled:opacity-30"
                    title="Delete"
                  >
                    {deleting === a.id ? (
                      <svg className="w-4 h-4 animate-spin" viewBox="0 0 24 24" fill="none">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/>
                      </svg>
                    ) : (
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    )}
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-6">
              <button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
                className="px-3 py-1.5 text-sm bg-gray-900 border border-gray-700 rounded-lg text-gray-400 hover:text-white disabled:opacity-30 transition-colors"
              >
                ← Prev
              </button>
              <span className="text-sm text-gray-500">
                {page} / {totalPages}
              </span>
              <button
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="px-3 py-1.5 text-sm bg-gray-900 border border-gray-700 rounded-lg text-gray-400 hover:text-white disabled:opacity-30 transition-colors"
              >
                Next →
              </button>
            </div>
          )}
        </div>

        {/* Right: detail view — sidebar on lg+, full-screen modal on mobile */}
        {selected && (
          <>
            {/* Mobile overlay */}
            <div
              className="lg:hidden fixed inset-0 z-50 bg-black/70 backdrop-blur-sm"
              onClick={() => setSelected(null)}
            />
            <div className="lg:hidden fixed inset-x-0 bottom-0 z-50 max-h-[90vh] overflow-y-auto rounded-t-2xl">
              <DetailView analysis={selected} onClose={() => setSelected(null)} />
            </div>
            {/* Desktop sidebar */}
            <div className="hidden lg:block lg:w-[420px] flex-shrink-0">
              <DetailView analysis={selected} onClose={() => setSelected(null)} />
            </div>
          </>
        )}
      </div>
    </>
  )
}

function DetailView({ analysis, onClose }: { analysis: Analysis; onClose: () => void }) {
  const r: AnalysisResult = analysis.result
  const METRICS = [
    { key: 'hookStrength' as const, label: 'Hook Strength', description: 'How compelling is the opening?' },
    { key: 'emotionalEngagement' as const, label: 'Emotional Engagement', description: 'Emotional response trigger?' },
    { key: 'clarity' as const, label: 'Clarity', description: 'Is the message clear?' },
    { key: 'retentionPotential' as const, label: 'Retention Potential', description: 'Will they stick around?' },
  ]

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5 space-y-5 animate-slide-up sticky top-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <span className="text-sm font-semibold text-white">Full Result</span>
        <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      {/* Original content */}
      <div>
        <p className="text-xs text-gray-500 mb-1">Content</p>
        <p className="text-xs text-gray-400 leading-relaxed line-clamp-3">{analysis.content}</p>
      </div>

      {/* Score */}
      <div className="flex items-center justify-center">
        <ScoreGauge score={r.viralScore} />
      </div>

      {/* Summary */}
      <p className="text-xs text-gray-400 leading-relaxed">{r.summary}</p>

      {/* Metrics */}
      <div className="grid grid-cols-2 gap-2">
        {METRICS.map(m => (
          <MetricCard key={m.key} label={m.label} value={r[m.key]} description={m.description} />
        ))}
      </div>

      {/* Rewritten hook */}
      {r.rewrittenHook && (
        <div className="bg-gray-800/60 rounded-xl border border-indigo-500/20 p-3">
          <p className="text-xs text-gray-500 mb-1">Improved hook</p>
          <p className="text-xs text-indigo-300 font-medium leading-relaxed">{r.rewrittenHook}</p>
        </div>
      )}

      {/* Suggestions */}
      <div>
        <p className="text-xs text-gray-500 mb-2">Suggestions</p>
        <SuggestionList suggestions={r.suggestions} />
      </div>
    </div>
  )
}
