import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'ViralLens — AI Content Virality Analyzer',
  description: 'Analyze your content for viral potential using AI',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
